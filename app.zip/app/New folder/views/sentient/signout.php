<?php
header('Location:/quiz');