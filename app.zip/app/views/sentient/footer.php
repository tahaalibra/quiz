<div id="footer">
      <div id="f_area1">
        <br>Manifesto About Contact	Apps Developers Blog Privacy Terms Help <br><br>
        CatchPenny-Project 2015
      </div>
    </div>

</body>
</html>
