<?php
header('Location:'.INSTALL_FOLDER);