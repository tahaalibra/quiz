<?php

class home_controller extends controller{
    
    
    function home()
    {
        //$this->set("title","Welcome to Quiz");
                  
       
    }
    
    
}

