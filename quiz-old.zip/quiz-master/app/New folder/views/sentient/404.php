<html>
<head>
    <title><?php echo $title;?></title>
     
      <link rel="stylesheet" type="text/css" href="http://localhost/quiz/public/css/404.css">
</head>
</html>