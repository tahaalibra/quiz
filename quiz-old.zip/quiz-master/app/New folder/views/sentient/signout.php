<?php
header('Location:/quiz');