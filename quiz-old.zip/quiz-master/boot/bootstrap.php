<?php
/*
 * Bootfile:
 * Load Essential website files 
 */

//temp
//require_once(ROOT.'\core\auth\functions.php');

require_once(ROOT.DS.'boot'.DS.'en.php');
//Load Configaration file
require_once(ROOT.DS.'boot'.DS.'config.php');
//Load Initialization process
require_once(ROOT.DS.'boot'.DS.'init.php');
//load language




