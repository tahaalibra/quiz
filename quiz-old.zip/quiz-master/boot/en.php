<?php
$lang = array(
"title"=>"Welcome to the Quiz",

); 
  